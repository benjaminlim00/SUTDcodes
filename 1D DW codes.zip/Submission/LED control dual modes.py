import RPi.GPIO as GPIO
import time
import signal
import sys
from firebase import firebase
from datetime import datetime

# use Raspberry Pi board pin numbers
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False) #remove warnings

# set GPIO Pins
pinTrigger = 18
pinEcho = 24
GPIO_LED = 12

#function to turn off the program
def close(signal, frame):
    print("\nKeyboard interupt, turning off program...\n")
    GPIO.cleanup() 
    sys.exit(0)

signal.signal(signal.SIGINT, close)

# set GPIO input and output channels
GPIO.setup(pinTrigger, GPIO.OUT)
GPIO.setup(pinEcho, GPIO.IN)
GPIO.setup(GPIO_LED, GPIO.OUT)        # LED output pin

##### Firebase authentication #####
url = 'https://helloworld-8cf45.firebaseio.com/' # URL to Firebase database
token = 'YW3EBnf50kQ3dAbhsoeaIMy0poFDKe3R1TP6BWAm' # unique token used for authentication

firebase=firebase.FirebaseApplication(url,token)

##### PWM #####
pwm_led = GPIO.PWM(GPIO_LED, 100)      # 100Hz PWM frequency

pwm_led.start(10)                     # 10% brightness

##### Code #####
lowls = firebase.get('/LOW') #obtain list of timings where the led is switched to low brightness from firebase
highls = firebase.get('/HIGH') #obtain list of timings where the led is switched to high brightness from firebase

try:
    ########################CODE FOR SENSOR MODE##########################
    while True:
        modestate = firebase.get('/buttons_state') #retrieve button state from firebase
        if modestate[0] == 'down': #currently in sensor mode
            ######checking distance###########
            # set Trigger to HIGH
            GPIO.output(pinTrigger, True)
            # set Trigger after 0.01ms to LOW
            time.sleep(0.00001)
            GPIO.output(pinTrigger, False)
            
            startTime = time.time()
            stopTime = time.time()
            
            # save start time
            while 0 == GPIO.input(pinEcho):
                startTime = time.time()
            
            # save time of arrival
            while 1 == GPIO.input(pinEcho):
                stopTime = time.time()
            
            # time difference between start and arrival
            TimeElapsed = stopTime - startTime
            # multiply with the sonic speed (34300 cm/s)
            # and divide by 2, because there and back
            distance = (TimeElapsed * 34300) / 2
            
            print ("Distance: %.1f cm" % distance)
            
            time_stamp = datetime.now().strftime("%S")
            print("current timestamp: {}".format(time_stamp))
            
            
            if distance > 18:               # When no object in front of sensor
                lowls.append(time_stamp) #add timestamp to list of dim led timings
                
                pwm_led.ChangeDutyCycle(10) #dim the led
                firebase.put('/','LOW', lowls) #update the LOW list on firebase with new dim led timing
                time.sleep(0.1) #small delay
    
            else:             # When object in front of sensor
    
                print("Object detected")
                highls.append(time_stamp) #add timestamp to list of bright led timings
                
                pwm_led.ChangeDutyCycle(100) #brighten the led
                firebase.put('/','HIGH', highls) #update the HIGH list on firebase with new dim led timing
                time.sleep(5)       # Remains at 100% brightness for 5 seconds
        else: ################currently in auto-prediction mode##############################
            
            highls = firebase.get('/HIGH') #obtain list of timings where the led is set to bright from firebase
            
            lowls = firebase.get('/LOW') #obtain list of timings where the led is set to dim from firebase
            
            time_stamp = datetime.now().strftime("%S") #obtain current timestamp
            print("current timestamp: {}".format(time_stamp)) #print the time_stamp
            
            if time_stamp in highls and time_stamp in lowls: #for current timestamp, there is a previous mix of both bright and dim states
                #hence we should compare and see whether it is more often in bright/dim state, then set led to be bright/dim accordingly.
                highcount = highls.count(time_stamp) #count of how many times given timestamp is in high list
                lowcount = lowls.count(time_stamp) #count of how many times given timestamp is in low list
                if highcount >= lowcount: #led bright more than led dim
                    pwm_led.ChangeDutyCycle(100)
                    print('In both list, more in high list')
                else: #led bright less than led dim
                    pwm_led.ChangeDutyCycle(10)
                    print('In both list, more in low list')
            elif time_stamp in highls: #for given timestamp, the led has only ever been in bright state, hence should be in bright state.
                pwm_led.ChangeDutyCycle(100)
                print('In high list only')
            elif time_stamp in lowls: #for given timestamp, the led has only ever been in dim state, hence should be in dim state.
                pwm_led.ChangeDutyCycle(10)
                print('In low list only')
            else: #current timestamp has never been assigned a dim/bright state in firebase, meaning that it is within the 5 seconds delay time after
                #the led is set to bright state, in sensor mode. Hence led should be set to bright
                pwm_led.ChangeDutyCycle(100)
                print('In none of the lists')
            time.sleep(0.1)


except KeyboardInterrupt:
    print("Exiting Program")

finally:
    GPIO.cleanup()