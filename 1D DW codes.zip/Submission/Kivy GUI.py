import kivy
from kivy.app import App
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.gridlayout import GridLayout
from kivy.graphics import Color, Rectangle
from firebase import firebase

##### Firebase authentication #####

url = 'https://helloworld-8cf45.firebaseio.com/' # URL to Firebase database
token = 'YW3EBnf50kQ3dAbhsoeaIMy0poFDKe3R1TP6BWAm' # unique token used for authentication

firebase=firebase.FirebaseApplication(url,token)

class MyApp(App):
    #build the app
    def build(self):
        # Set up the layout:
        layout = GridLayout(cols=2, spacing=30, padding=30, row_default_height=150)

        # Make the background gray:
        with layout.canvas.before:
            Color(.2,.2,.2,1)
            self.rect = Rectangle(size=(800,600), pos=layout.pos)

        # Create the rest of the UI objects (and bind them to callbacks):
        self.sensorbut = ToggleButton(text="Sensor mode")
        self.sensorbut.bind(on_press=self.press_callback)
        self.autobut = ToggleButton(text="Auto-prediction mode")
        self.autobut.bind(on_press=self.press_callback)
        
        self.sensorbut.state = 'down' #program starts with sensor state on.
        lstemp = ['down', 'normal']
        firebase.put('/', 'buttons_state', lstemp) # update buttons_state in firebase so that program starts in sync.   
        
        
        # Add the UI elements to the layout:
        layout.add_widget(self.sensorbut)
        layout.add_widget(self.autobut)
        
        
        return layout
    
    def press_callback(self, instance):
        
        if instance.text == 'Sensor mode': #if button pressed is sensor button
            if instance.state == "down": #if sensor button turned on
                print ("sensor mode on")
                self.autobut.state = "normal" #turn the auto button off
            else:
                print ("sensor mode off") #if sensor button turned off
                self.autobut.state = "down" #turn the auto button on
                
        elif instance.text == 'Auto-prediction mode': #if button pressed is auto button
            if instance.state == "down": #if auto button turned on
                print ("auto mode on")
                self.sensorbut.state = "normal" #turn the sensor button on
            else:
                print ("auto mode off") #if auto button turned off
                self.sensorbut.state = "down" #turn the auto button off
        
        #to upload button state to firebase
        ls = [self.sensorbut.state, self.autobut.state]
        firebase.put('/', 'buttons_state', ls) # put the button_state into firebase node
        #print('success') #to check if button state successfully uploaded
    
  
def reset(): #function to reset kivy window
    import kivy.core.window as window
    from kivy.base import EventLoop
    if not EventLoop.event_listeners:
        from kivy.cache import Cache
        window.Window = window.core_select_lib('window', \
                                               window.window_impl, True)
        Cache.print_usage()
        for cat in Cache._categories:
            Cache._objects[cat] = {}
            

if __name__ == '__main__':
    reset()
    MyApp().run()