#importing requried libraries

import os
import glob
import time

import numpy as np

import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.config import Config

os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')

base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'

#setting the window size
Window.size = (800,200)
Config.set('graphics','fullscreen','auto')

#creating class called MyApp
class MyApp(App):
    #variables
    curtimeno = 0
    predtimeno = 0
    tempnow = 0
    tempmydata = []
    mydata = []
    newdata = []
    datasplit = []
    ctime = 0

    ccount = 0
    
    
    def build(self):
        
        # Set up the layout:
        layout = GridLayout(cols=4, padding=(10,10,10,10))

        # Create the rest of the UI objects (and bind them to callbacks, if necessary):
        
        self.curtime = Label(text = 'Current Time: ', font_size=20)
        self.curtimeval = Label(text = '{} seconds'.format(self.curtimeno), font_size=20)
        self.predtime = Label(text = 'Prediction Time: ', font_size=20)
        self.predtimeval = Label(text = '{} seconds'.format(self.predtimeno), font_size=20)        
        self.tempreading = Label(text = 'Temperature Reading: ', font_size=20)
        self.tempreadingval = Label(text = '- degrees', font_size=20)
        self.predtemp = Label(text = 'Predicted Temperature: ', font_size=20)
        self.predtempval = Label(text = 'Predicting...', font_size=20)
        

        # Add the UI elements to the layout:
        layout.add_widget(self.curtime)
        layout.add_widget(self.curtimeval)
        layout.add_widget(self.predtime)
        layout.add_widget(self.predtimeval)
        layout.add_widget(self.tempreading)
        layout.add_widget(self.tempreadingval)
        layout.add_widget(self.predtemp)
        layout.add_widget(self.predtempval)
        
        Clock.schedule_interval(self.updatect, 1)
        Clock.schedule_interval(self.updatept, 1)
        Clock.schedule_interval(self.updatetemp, 1)
        Clock.schedule_interval(self.updatepred, 28)
        Clock.schedule_interval(self.readingupdate, 1)
    
        return layout
    # this function is called per second to update the current timing
    def updatect(self, instance):
        
        self.curtimeno += 1
        self.curtimeval.text = '{} seconds'.format(self.curtimeno)
        
    # this function is called per second up until temperature is predicted to update the predicted timing
    def updatept(self, instance):
       if self.predtimeno >= 21:
           
           return None
           
       self.predtimeno += 1
       self.predtimeval.text = '{} seconds'.format(self.predtimeno)
       
    #this function is called per second to update the current temperature reading 
    def updatetemp(self, instance):
        self.ccount += 1
        if self.ccount != 1:
            self.tempmydata = self.mydata[-1]
            # mydata is a list of list of strings
            # tempmydata is the last list within the list of lists

            self.tempmydata = self.tempmydata[0].split(',') #we split it into a list of size 2

            self.tempnow = self.tempmydata[1] #access the latest temperature value
            self.tempreadingval.text = '{} degrees'.format(self.tempnow) #update the current temperature value
                   
    def updatepred(self, instance):
        
        self.newdata = self.mydata #data in the form of list

        self.datasplit = [] #similar to above function
        for data in self.newdata:
            minils = data[0].split(',')
            self.datasplit.append(minils)
            
        dataarray = np.asarray(self.datasplit) 
        
        
        #retrieve values at T=19s and T=20s which are at index 18 & 19
        
        dataarray19 = dataarray[18,:]
        dataarray20 = dataarray[19,:]
        
        xdiff = float(dataarray19[0]) - float(dataarray20[0])
        ydiff = float(dataarray19[1]) - float(dataarray20[1])
        
        
        xvalue = ydiff / xdiff #xvalue of the best fit line
        
        #from maachine learning and regression, we found these
        m = 17.0
        c = 0.0
        
        yvalue = m * xvalue + c
        #since yvalue = Tw - T20, Tw = yvalue + T20
        #lets call Tw pred_temp
        pred_temp = yvalue + float(dataarray20[1])
        pred_temp = round(pred_temp, 5)
        
        self.predtempval.text = str(pred_temp)
        return 0
    
    def readingupdate(self, *args):
    #this function is called every second to run the read_temp() function which will update the mydata list with time and temperature values    
                
        def read_temp_raw():
            f = open(device_file, 'r')
            lines = f.readlines()
            f.close()
            return lines
        
        def read_temp():
            lines = read_temp_raw() 
            while lines[0].strip()[-3:] != 'YES':
                time.sleep(0.2)
                lines = read_temp_raw()
            equals_pos = lines[1].find('t=')
            if equals_pos != -1:
                temp_string = lines[1][equals_pos+2:]
                temp_c = float(temp_string) / 1000.0
                temp_f = temp_c * 9.0 / 5.0 + 32.0
                return temp_c, temp_f
        
        ls =[]
        tempstr = "{},{}".format(str(float(self.ctime)),str(read_temp()[0]))
        print(tempstr)
        ls.append(tempstr)
        self.mydata.append(ls)
        self.ctime += 1


if __name__ == '__main__':
    MyApp().run()
